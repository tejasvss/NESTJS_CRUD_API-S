
export class UpdateUserDto {

    user_name: string;

    email: string;

    mobileNumber: number;

    role: number;

}